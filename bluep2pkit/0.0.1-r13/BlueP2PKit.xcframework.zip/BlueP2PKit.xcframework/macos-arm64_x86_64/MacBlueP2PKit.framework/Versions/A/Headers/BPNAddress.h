//
//  BPNAddress.h
//  MacBlueP2PKit
//
//  Created by Pavel Kasila on 24.04.21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BPNAddress : NSObject

- (id) initWithBase58String:(NSString *)string;

- (NSString *) getString;

- (uint8_t *) getDigest;

@end

NS_ASSUME_NONNULL_END
