//
//  BPNNetworkDelegate.h
//  MacBlueP2PKit
//
//  Created by Pavel Kasila on 21.04.21.
//

#import <Foundation/Foundation.h>
#import "BPNMetadata.h"
#import "BPNAddress.h"

NS_ASSUME_NONNULL_BEGIN

@protocol BPNNetworkDelegate <NSObject>

- (void) network:(id)manager withMetadata:(BPNMetadata*)metadata withData:(NSData *)data withCallback:(void (^)(NSData*))callback;

- (void) network:(id)manager registered:(NSUInteger)port;

- (void) network:(id)manager nodeConnected:(BPNAddress*)address;

@end

NS_ASSUME_NONNULL_END
