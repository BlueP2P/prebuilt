//
//  BPNManager.h
//  MacBlueP2PKit
//
//  Created by Pavel Kasila on 21.04.21.
//

#import <Foundation/Foundation.h>
#import "BPNNetworkDelegate.h"
#import "BPNMetadata.h"

NS_ASSUME_NONNULL_BEGIN

@interface BPNManager : NSObject

- (id)init;

- (NSUInteger)addDelegate:(NSObject<BPNNetworkDelegate> *)delegate;

- (void)sendData:(NSData *)data fromPort:(NSUInteger)port withMetadata:(BPNMetadata*)metadata;

@end

NS_ASSUME_NONNULL_END
