//
//  BPNMetadata.h
//  MacBlueP2PKit
//
//  Created by Pavel Kasila on 24.04.21.
//

#import <Foundation/Foundation.h>
#if TARGET_NAME == MacBlueP2PKit
#import <MacBlueP2PKit/BPNAddress.h>
#elif TARGET_NAME == iOSBlueP2PKit
#import <iOSBlueP2PKit/BPNAddress.h>
#endif

NS_ASSUME_NONNULL_BEGIN

struct BPNMetadata {
    uint64_t id;
    uint64_t replyID;
    BPNAddress *endpoint;
    uint64_t endpointPort;
    BPNAddress *sender;
    uint64_t senderPort;
    uint64_t routeLength;
};
typedef struct BPNMetadata BPNMetadata;

NS_ASSUME_NONNULL_END
