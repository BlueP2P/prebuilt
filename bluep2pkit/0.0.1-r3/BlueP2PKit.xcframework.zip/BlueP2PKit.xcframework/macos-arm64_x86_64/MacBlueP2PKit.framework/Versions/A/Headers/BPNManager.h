//
//  BPNManager.h
//  MacBlueP2PKit
//
//  Created by Pavel Kasila on 21.04.21.
//

#import <Foundation/Foundation.h>
#import "BPNNetworkDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface BPNManager : NSObject {
    void *network;
}

- (id)init;

- (NSUInteger)addDelegate:(NSObject<BPNNetworkDelegate> *)delegate;

@end

NS_ASSUME_NONNULL_END
