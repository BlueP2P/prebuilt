//
//  BPNNetworkDelegate.h
//  MacBlueP2PKit
//
//  Created by Pavel Kasila on 21.04.21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol BPNNetworkDelegate <NSObject>

- (void) network:(id)manager withData:(NSData *)data withCallback:(void (^)(NSData*))callback;

- (void) network:(id)manager registered:(NSUInteger)port;

@end

NS_ASSUME_NONNULL_END
