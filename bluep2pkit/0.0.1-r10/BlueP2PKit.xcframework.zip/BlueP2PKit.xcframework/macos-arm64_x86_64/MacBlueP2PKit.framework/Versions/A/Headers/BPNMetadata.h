//
//  BPNMetadata.h
//  MacBlueP2PKit
//
//  Created by Pavel Kasila on 24.04.21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

struct BPNMetadata {
    uint64_t id;
    uint64_t replyID;
    uint8_t endpoint[64];
    uint64_t endpointPort;
    uint8_t sender[64];
    uint64_t senderPort;
    uint64_t routeLength;
};
typedef struct BPNMetadata BPNMetadata;

NS_ASSUME_NONNULL_END
