//
//  BPNMetadata.h
//  MacBlueP2PKit
//
//  Created by Pavel Kasila on 24.04.21.
//

#import <Foundation/Foundation.h>
#if TARGET_NAME == MacBlueP2PKit
#import <MacBlueP2PKit/BPNAddress.h>
#elif TARGET_NAME == iOSBlueP2PKit
#import <iOSBlueP2PKit/BPNAddress.h>
#endif

NS_ASSUME_NONNULL_BEGIN

@interface BPNMetadata : NSObject

@property(nonatomic) NSUInteger id;
@property(nonatomic) NSUInteger replyID;
@property(nonatomic) BPNAddress *endpoint;
@property(nonatomic) NSUInteger endpointPort;
@property(nonatomic) BPNAddress *sender;
@property(nonatomic) NSUInteger senderPort;
@property(nonatomic) NSUInteger routeLength;

@end

NS_ASSUME_NONNULL_END
